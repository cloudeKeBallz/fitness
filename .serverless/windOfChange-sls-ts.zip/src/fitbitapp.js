"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express = require("express");
const body_parser_1 = require("body-parser");
const cors = require("cors");
//import { eventContext } from 'aws-serverless-express/middleware';
const axios_1 = require("axios");
const querystring = require("querystring");
const fitbitToken_dao_1 = require("./dao/fitbitToken.dao");
const persistFitbit_dao_1 = require("./dao/persistFitbit.dao");
function configureFitbitApp() {
    const app = express();
    app.set('view engine', 'pug');
    app.use(cors());
    app.use(body_parser_1.json());
    app.use(body_parser_1.urlencoded({
        extended: true,
    }));
    //app.use(eventContext());
    app.get('/', (req, res) => {
        res.render('home');
    });
    app.get('/fitbit/oauth/redirect', fitbitRedirect);
    app.get('/fitbit/oauth/codeflow', fitbitFlow);
    return app;
}
exports.configureFitbitApp = configureFitbitApp;
async function fitbitFlow(req, res) {
    try {
        let fitbitAccessTokenDao = new fitbitToken_dao_1.FitBitAccessTokenDao('fitbitconfig');
        console.log('User details being fetched : ', req.query.user);
        let result = await fitbitAccessTokenDao.get(req.query.user);
        console.log('Result from config table from app.ts : ', JSON.stringify(result.Item));
        if (result.Item !== null && result.Item !== undefined) {
            res.redirect(301, '/fitbit/oauth/redirect?state=user:' +
                req.query.user +
                ',isnew:false&code=none');
            //res.send(fetchResponse);
        }
        else {
            let callback_url = 'https://emzkzxxqb7.execute-api.eu-west-1.amazonaws.com/dev/fitbit/oauth/redirect';
            let scope = 'activity heartrate location nutrition profile settings sleep social weight';
            let expires_in = '604800';
            let state = 'user:' + req.query.user + ',isNew:true';
            let client_id = '22DJDD';
            let response_type = 'code';
            let redirect_url = encodeURI('https://www.fitbit.com/oauth2/authorize?' +
                'response_type=' +
                response_type +
                '&client_id=' +
                client_id +
                '&redirect_uri=' +
                callback_url +
                '&scope=' +
                scope +
                '&expires_in' +
                expires_in +
                '&state=' +
                state);
            //let redirectUrl: string = 'https://www.fitbit.com/oauth2/authorize?response_type=code&client_id=22DJDD&redirect_uri=http%3A%2F%2Flocalhost%3A3000%2Ffitbit%2Foauth%2Fredirect&scope=activity%20heartrate%20location%20nutrition%20profile%20settings%20sleep%20social%20weight&expires_in=604800&state=userid:suhas';
            res.redirect(301, redirect_url);
        }
    }
    catch (e) { }
}
async function fitbitRedirect(req, res) {
    const authcode = req.query.code;
    console.log('The auth code is : ' + authcode);
    const state = req.query.state;
    let userId = state.split(',')[0].split(':')[1];
    let isNew = state.split(',')[1].split(':')[1];
    let fitbitAccessTokenDao = new fitbitToken_dao_1.FitBitAccessTokenDao('fitbitconfig');
    console.log('User id : ', userId);
    console.log('isUserNew:', isNew);
    //let activity_url = 'https://api.fitbit.com/1/user/-/activities/date/2019-04-03.json'
    let activity_steps_timeseries = 'https://api.fitbit.com/1/user/-/activities/steps/date/2018-04-03/7d.json';
    let activity_calories_timeseries = 'https://api.fitbit.com/1/user/-/activities/calories/date/2018-04-03/7d.json';
    let activity_lifetime = 'https://api.fitbit.com/1/user/-/activities.json';
    let authconfig = { headers: {} };
    let refreshToken = '';
    let userResult = await fitbitAccessTokenDao.get(userId);
    console.log('userTokenDetails', userResult.Item);
    if (isNew === 'true') {
        let reqBody = {
            clientId: '22DJDD',
            grant_type: 'authorization_code',
            redirect_uri: 'https://emzkzxxqb7.execute-api.eu-west-1.amazonaws.com/dev/fitbit/oauth/redirect',
            code: authcode,
        };
        let config = {
            headers: {
                Authorization: 'Basic MjJESkREOmQxYjllOWRmMDUwNGJhOTMxM2FkODg1M2MwYjA0NDRh',
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        };
        const url = 'https://api.fitbit.com/oauth2/token';
        let tokenResp = await axios_1.default.post(url, querystring.stringify(reqBody), {
            headers: config.headers,
        });
        console.log("Response token : ");
        console.log(tokenResp);
        await fitbitAccessTokenDao.post(userId, tokenResp.data.access_token, tokenResp.data.token_type, tokenResp.data.refresh_token, tokenResp.data.expires_in);
        refreshToken = tokenResp.data.refresh_token;
        let accessToken = tokenResp.data.access_token;
        authconfig.headers = {
            Authorization: 'Bearer ' + accessToken,
        };
    }
    else {
        console.log('Entered the existing user auth flow ');
        console.log('User Id : ' + userId);
        refreshToken = userResult.Item.refreshToken;
        authconfig.headers = {
            Authorization: 'Bearer ' + userResult.Item.accessToken,
        };
        console.log("Done the authorization check for the exiting user");
    }
    let activityStepsTimeSeriesResponse = null;
    let activityCaloriesTimeSeriesResponse = null;
    let activityLifetime = null;
    try {
        activityStepsTimeSeriesResponse = await axios_1.default.get(activity_steps_timeseries, { headers: authconfig.headers });
        activityCaloriesTimeSeriesResponse = await axios_1.default.get(activity_calories_timeseries, { headers: authconfig.headers });
        activityLifetime = await axios_1.default.get(activity_lifetime, {
            headers: authconfig.headers,
        });
    }
    catch (error) {
        console.log("Error in promise resolution : ");
        console.log(error.response.status);
        let refreshTokenConfig = {
            headers: {
                Authorization: 'Basic MjJESkREOmQxYjllOWRmMDUwNGJhOTMxM2FkODg1M2MwYjA0NDRh',
            },
        };
        console.log("Refresh token val : ");
        console.log(refreshToken);
        let refreshReqBody = {
            grant_type: 'refresh_token',
            refresh_token: refreshToken,
        };
        let refreshTokenResponse = await axios_1.default.post('https://api.fitbit.com/oauth2/token', querystring.stringify(refreshReqBody), { headers: refreshTokenConfig.headers });
        let accessToken = refreshTokenResponse.data.access_token;
        let refreshTokenNew = refreshTokenResponse.data.refresh_token;
        console.log('Access token : ' + accessToken);
        console.log('Refresh Token : ' + refreshTokenNew);
        await fitbitAccessTokenDao.post(userId, refreshTokenResponse.data.access_token, refreshTokenResponse.data.token_type, refreshTokenResponse.data.refresh_token, refreshTokenResponse.data.expiry_date);
        authconfig.headers = {
            Authorization: 'Bearer ' + accessToken,
        };
        activityStepsTimeSeriesResponse = await axios_1.default.get(activity_steps_timeseries, { headers: authconfig.headers });
        activityCaloriesTimeSeriesResponse = await axios_1.default.get(activity_calories_timeseries, { headers: authconfig.headers });
        activityLifetime = await axios_1.default.get(activity_lifetime, {
            headers: authconfig.headers,
        });
        console.log("Moving out of the catch block : ");
    }
    if (activityStepsTimeSeriesResponse.status == 200 ||
        activityCaloriesTimeSeriesResponse.status == 200 ||
        activityLifetime.status == 200) {
        let timeseriesData = activityStepsTimeSeriesResponse.data['activities-steps'];
        let fitbitStoreDao = new persistFitbit_dao_1.FitbitDao('fitbitsteps');
        let timeseriesCalData = activityCaloriesTimeSeriesResponse.data['activities-calories'];
        let fitbitCaloriesStoreDao = new persistFitbit_dao_1.FitbitDao('fitbitcalories');
        timeseriesData.forEach(async (data) => {
            console.log(data);
            await fitbitStoreDao.post(userId + data.dateTime, userId, data.dateTime, data.value);
        });
        timeseriesCalData.forEach(async (data) => {
            await fitbitCaloriesStoreDao.post(userId + data.dateTime, userId, data.dateTime, data.value);
        });
        res.send({
            // activity_steps_timeseries: activityStepsTimeSeriesResponse.data,
            // activity_calories_timeseries: activityCaloriesTimeSeriesResponse.data,
            // activity_lifetime: activityLifetime.data,
            message: "success",
            status: 200
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZml0Yml0YXBwLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZml0Yml0YXBwLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsbUNBQW1DO0FBQ25DLDZDQUErQztBQUMvQyw2QkFBNkI7QUFDN0IsbUVBQW1FO0FBQ25FLGlDQUEwQjtBQUMxQiwyQ0FBMkM7QUFDM0MsMkRBQTZEO0FBQzdELCtEQUFvRDtBQUlwRCxTQUFnQixrQkFBa0I7SUFDaEMsTUFBTSxHQUFHLEdBQUcsT0FBTyxFQUFFLENBQUM7SUFDdEIsR0FBRyxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDOUIsR0FBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDO0lBQ2hCLEdBQUcsQ0FBQyxHQUFHLENBQUMsa0JBQUksRUFBRSxDQUFDLENBQUM7SUFDaEIsR0FBRyxDQUFDLEdBQUcsQ0FDTCx3QkFBVSxDQUFDO1FBQ1QsUUFBUSxFQUFFLElBQUk7S0FDZixDQUFDLENBQ0gsQ0FBQztJQUVGLDBCQUEwQjtJQUUxQixHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsRUFBRTtRQUN4QixHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ3JCLENBQUMsQ0FBQyxDQUFDO0lBRUgsR0FBRyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsRUFBRSxjQUFjLENBQUMsQ0FBQztJQUNsRCxHQUFHLENBQUMsR0FBRyxDQUFDLHdCQUF3QixFQUFFLFVBQVUsQ0FBQyxDQUFDO0lBQzlDLE9BQU8sR0FBRyxDQUFDO0FBQ2IsQ0FBQztBQXBCRCxnREFvQkM7QUFFRCxLQUFLLFVBQVUsVUFBVSxDQUN2QixHQUFvQixFQUNwQixHQUFxQjtJQUVyQixJQUFJO1FBQ0YsSUFBSSxvQkFBb0IsR0FBeUIsSUFBSSxzQ0FBb0IsQ0FDdkUsY0FBYyxDQUNmLENBQUM7UUFDRixPQUFPLENBQUMsR0FBRyxDQUFDLCtCQUErQixFQUFFLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDN0QsSUFBSSxNQUFNLEdBQWtCLE1BQU0sb0JBQW9CLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDM0UsT0FBTyxDQUFDLEdBQUcsQ0FDVCx5Q0FBeUMsRUFDekMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQzVCLENBQUM7UUFFRixJQUFJLE1BQU0sQ0FBQyxJQUFJLEtBQUssSUFBSSxJQUFJLE1BQU0sQ0FBQyxJQUFJLEtBQUssU0FBUyxFQUFFO1lBQ3JELEdBQUcsQ0FBQyxRQUFRLENBQ1YsR0FBRyxFQUNILG9DQUFvQztnQkFDbEMsR0FBRyxDQUFDLEtBQUssQ0FBQyxJQUFJO2dCQUNkLHdCQUF3QixDQUMzQixDQUFDO1lBQ0YsMEJBQTBCO1NBQzNCO2FBQU07WUFDTCxJQUFJLFlBQVksR0FDZCxrRkFBa0YsQ0FBQztZQUNyRixJQUFJLEtBQUssR0FDUCw0RUFBNEUsQ0FBQztZQUMvRSxJQUFJLFVBQVUsR0FBRyxRQUFRLENBQUM7WUFDMUIsSUFBSSxLQUFLLEdBQUcsT0FBTyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxHQUFHLGFBQWEsQ0FBQztZQUNyRCxJQUFJLFNBQVMsR0FBRyxRQUFRLENBQUM7WUFDekIsSUFBSSxhQUFhLEdBQUcsTUFBTSxDQUFDO1lBQzNCLElBQUksWUFBWSxHQUFHLFNBQVMsQ0FDMUIsMENBQTBDO2dCQUN4QyxnQkFBZ0I7Z0JBQ2hCLGFBQWE7Z0JBQ2IsYUFBYTtnQkFDYixTQUFTO2dCQUNULGdCQUFnQjtnQkFDaEIsWUFBWTtnQkFDWixTQUFTO2dCQUNULEtBQUs7Z0JBQ0wsYUFBYTtnQkFDYixVQUFVO2dCQUNWLFNBQVM7Z0JBQ1QsS0FBSyxDQUNSLENBQUM7WUFDRix1VEFBdVQ7WUFDdlQsR0FBRyxDQUFDLFFBQVEsQ0FBQyxHQUFHLEVBQUUsWUFBWSxDQUFDLENBQUM7U0FDakM7S0FDRjtJQUFDLE9BQU8sQ0FBQyxFQUFFLEdBQUU7QUFDaEIsQ0FBQztBQUVELEtBQUssVUFBVSxjQUFjLENBQzNCLEdBQW9CLEVBQ3BCLEdBQXFCO0lBRXJCLE1BQU0sUUFBUSxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDO0lBQ2hDLE9BQU8sQ0FBQyxHQUFHLENBQUMscUJBQXFCLEdBQUcsUUFBUSxDQUFDLENBQUM7SUFDOUMsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUM7SUFDOUIsSUFBSSxNQUFNLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDL0MsSUFBSSxLQUFLLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFFOUMsSUFBSSxvQkFBb0IsR0FBeUIsSUFBSSxzQ0FBb0IsQ0FDdkUsY0FBYyxDQUNmLENBQUM7SUFFRixPQUFPLENBQUMsR0FBRyxDQUFDLFlBQVksRUFBRSxNQUFNLENBQUMsQ0FBQztJQUNsQyxPQUFPLENBQUMsR0FBRyxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUMsQ0FBQztJQUVqQyxzRkFBc0Y7SUFDdEYsSUFBSSx5QkFBeUIsR0FDM0IsMEVBQTBFLENBQUM7SUFDN0UsSUFBSSw0QkFBNEIsR0FDOUIsNkVBQTZFLENBQUM7SUFDaEYsSUFBSSxpQkFBaUIsR0FBRyxpREFBaUQsQ0FBQztJQUMxRSxJQUFJLFVBQVUsR0FBRyxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsQ0FBQztJQUNqQyxJQUFJLFlBQVksR0FBRyxFQUFFLENBQUM7SUFDdEIsSUFBSSxVQUFVLEdBQVEsTUFBTSxvQkFBb0IsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDN0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7SUFFakQsSUFBSSxLQUFLLEtBQUssTUFBTSxFQUFFO1FBQ3BCLElBQUksT0FBTyxHQUFHO1lBQ1osUUFBUSxFQUFFLFFBQVE7WUFDbEIsVUFBVSxFQUFFLG9CQUFvQjtZQUNoQyxZQUFZLEVBQ1Ysa0ZBQWtGO1lBQ3BGLElBQUksRUFBRSxRQUFRO1NBQ2YsQ0FBQztRQUVGLElBQUksTUFBTSxHQUFHO1lBQ1gsT0FBTyxFQUFFO2dCQUNQLGFBQWEsRUFDWCw0REFBNEQ7Z0JBQzlELGNBQWMsRUFBRSxtQ0FBbUM7YUFDcEQ7U0FDRixDQUFDO1FBRUYsTUFBTSxHQUFHLEdBQUcscUNBQXFDLENBQUM7UUFFbEQsSUFBSSxTQUFTLEdBQUcsTUFBTSxlQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxXQUFXLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQ3BFLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTztTQUN4QixDQUFDLENBQUM7UUFFSCxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLENBQUE7UUFDaEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQTtRQUV0QixNQUFNLG9CQUFvQixDQUFDLElBQUksQ0FDN0IsTUFBTSxFQUNOLFNBQVMsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUMzQixTQUFTLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFDekIsU0FBUyxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQzVCLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUMxQixDQUFDO1FBQ0YsWUFBWSxHQUFHLFNBQVMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDO1FBQzVDLElBQUksV0FBVyxHQUFHLFNBQVMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDO1FBRTlDLFVBQVUsQ0FBQyxPQUFPLEdBQUc7WUFDbkIsYUFBYSxFQUFFLFNBQVMsR0FBRyxXQUFXO1NBQ3ZDLENBQUM7S0FDSDtTQUFNO1FBQ0wsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQ0FBc0MsQ0FBQyxDQUFDO1FBQ3BELE9BQU8sQ0FBQyxHQUFHLENBQUMsWUFBWSxHQUFHLE1BQU0sQ0FBQyxDQUFDO1FBRW5DLFlBQVksR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQztRQUU1QyxVQUFVLENBQUMsT0FBTyxHQUFHO1lBQ25CLGFBQWEsRUFBRSxTQUFTLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXO1NBQ3ZELENBQUM7UUFFRixPQUFPLENBQUMsR0FBRyxDQUFDLG1EQUFtRCxDQUFDLENBQUE7S0FFakU7SUFFRCxJQUFJLCtCQUErQixHQUFHLElBQUksQ0FBQTtJQUMxQyxJQUFJLGtDQUFrQyxHQUFHLElBQUksQ0FBQTtJQUM3QyxJQUFJLGdCQUFnQixHQUFHLElBQUksQ0FBQTtJQUczQixJQUFJO1FBQ0YsK0JBQStCLEdBQUcsTUFBTSxlQUFLLENBQUMsR0FBRyxDQUMvQyx5QkFBeUIsRUFDekIsRUFBRSxPQUFPLEVBQUUsVUFBVSxDQUFDLE9BQU8sRUFBRSxDQUNoQyxDQUFDO1FBQ0Ysa0NBQWtDLEdBQUcsTUFBTSxlQUFLLENBQUMsR0FBRyxDQUNsRCw0QkFBNEIsRUFDNUIsRUFBRSxPQUFPLEVBQUUsVUFBVSxDQUFDLE9BQU8sRUFBRSxDQUNoQyxDQUFDO1FBQ0YsZ0JBQWdCLEdBQUcsTUFBTSxlQUFLLENBQUMsR0FBRyxDQUFDLGlCQUFpQixFQUFFO1lBQ3BELE9BQU8sRUFBRSxVQUFVLENBQUMsT0FBTztTQUM1QixDQUFDLENBQUM7S0FDSjtJQUFBLE9BQU0sS0FBSyxFQUFDO1FBRVgsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFBO1FBQzdDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQTtRQUVsQyxJQUFJLGtCQUFrQixHQUFHO1lBQ3ZCLE9BQU8sRUFBRTtnQkFDUCxhQUFhLEVBQ1gsNERBQTREO2FBQy9EO1NBQ0YsQ0FBQztRQUVGLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLENBQUMsQ0FBQTtRQUNuQyxPQUFPLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxDQUFBO1FBRXpCLElBQUksY0FBYyxHQUFHO1lBQ25CLFVBQVUsRUFBRSxlQUFlO1lBQzNCLGFBQWEsRUFBRSxZQUFZO1NBQzVCLENBQUM7UUFFRixJQUFJLG9CQUFvQixHQUFHLE1BQU0sZUFBSyxDQUFDLElBQUksQ0FDekMscUNBQXFDLEVBQ3JDLFdBQVcsQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLEVBQ3JDLEVBQUUsT0FBTyxFQUFFLGtCQUFrQixDQUFDLE9BQU8sRUFBRSxDQUN4QyxDQUFDO1FBQ0YsSUFBSSxXQUFXLEdBQUcsb0JBQW9CLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQztRQUN6RCxJQUFJLGVBQWUsR0FBRyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDO1FBRTlELE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLEdBQUcsV0FBVyxDQUFDLENBQUM7UUFDN0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsR0FBRyxlQUFlLENBQUMsQ0FBQztRQUVsRCxNQUFNLG9CQUFvQixDQUFDLElBQUksQ0FDN0IsTUFBTSxFQUNOLG9CQUFvQixDQUFDLElBQUksQ0FBQyxZQUFZLEVBQ3RDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxVQUFVLEVBQ3BDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxhQUFhLEVBQ3ZDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQ3RDLENBQUM7UUFFRixVQUFVLENBQUMsT0FBTyxHQUFHO1lBQ25CLGFBQWEsRUFBRSxTQUFTLEdBQUcsV0FBVztTQUN2QyxDQUFDO1FBRUYsK0JBQStCLEdBQUcsTUFBTSxlQUFLLENBQUMsR0FBRyxDQUMvQyx5QkFBeUIsRUFDekIsRUFBRSxPQUFPLEVBQUUsVUFBVSxDQUFDLE9BQU8sRUFBRSxDQUNoQyxDQUFDO1FBQ0Ysa0NBQWtDLEdBQUcsTUFBTSxlQUFLLENBQUMsR0FBRyxDQUNsRCw0QkFBNEIsRUFDNUIsRUFBRSxPQUFPLEVBQUUsVUFBVSxDQUFDLE9BQU8sRUFBRSxDQUNoQyxDQUFDO1FBQ0YsZ0JBQWdCLEdBQUcsTUFBTSxlQUFLLENBQUMsR0FBRyxDQUFDLGlCQUFpQixFQUFFO1lBQ3BELE9BQU8sRUFBRSxVQUFVLENBQUMsT0FBTztTQUM1QixDQUFDLENBQUM7UUFFSCxPQUFPLENBQUMsR0FBRyxDQUFDLGtDQUFrQyxDQUFDLENBQUE7S0FFaEQ7SUFFRCxJQUNFLCtCQUErQixDQUFDLE1BQU0sSUFBSSxHQUFHO1FBQzdDLGtDQUFrQyxDQUFDLE1BQU0sSUFBSSxHQUFHO1FBQ2hELGdCQUFnQixDQUFDLE1BQU0sSUFBSSxHQUFHLEVBQzlCO1FBQ0EsSUFBSSxjQUFjLEdBQ2hCLCtCQUErQixDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO1FBQzNELElBQUksY0FBYyxHQUFHLElBQUksNkJBQVMsQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUVsRCxJQUFJLGlCQUFpQixHQUNuQixrQ0FBa0MsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsQ0FBQztRQUNqRSxJQUFJLHNCQUFzQixHQUFHLElBQUksNkJBQVMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBRTdELGNBQWMsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLElBQVMsRUFBRSxFQUFFO1lBQ3pDLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDbEIsTUFBTSxjQUFjLENBQUMsSUFBSSxDQUN2QixNQUFNLEdBQUcsSUFBSSxDQUFDLFFBQVEsRUFDdEIsTUFBTSxFQUNOLElBQUksQ0FBQyxRQUFRLEVBQ2IsSUFBSSxDQUFDLEtBQUssQ0FDWCxDQUFDO1FBQ0osQ0FBQyxDQUFDLENBQUM7UUFFSCxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLElBQVMsRUFBRSxFQUFFO1lBQzVDLE1BQU0sc0JBQXNCLENBQUMsSUFBSSxDQUMvQixNQUFNLEdBQUcsSUFBSSxDQUFDLFFBQVEsRUFDdEIsTUFBTSxFQUNOLElBQUksQ0FBQyxRQUFRLEVBQ2IsSUFBSSxDQUFDLEtBQUssQ0FDWCxDQUFDO1FBQ0osQ0FBQyxDQUFDLENBQUM7UUFFSCxHQUFHLENBQUMsSUFBSSxDQUFDO1lBQ1AsbUVBQW1FO1lBQ25FLHlFQUF5RTtZQUN6RSw0Q0FBNEM7WUFDNUMsT0FBTyxFQUFHLFNBQVM7WUFDbkIsTUFBTSxFQUFFLEdBQUc7U0FDWixDQUFDLENBQUM7S0FDSjtBQUNILENBQUMifQ==